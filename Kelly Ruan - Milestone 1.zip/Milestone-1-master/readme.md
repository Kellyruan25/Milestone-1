Download this repository to use a starter code for your HTML project in OT CS Capstone

The blank.html document is a template that you can copy for every new page you make.

In the views folder is some generic navbar code.  Replace it with what you need.

in the scripts folder is a scripts.js file that will include the navbar on every page.

The index.html file is identical to the blank.html.

more instructions for how to use this here:
https://conchesness.github.io/SteveWright/javascript.html